plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "uz.elevate.padmap"
    compileSdk = 34

    defaultConfig {
        applicationId = "uz.elevate.padmap"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "2.0"
    }

    buildFeatures {
        aidl = false
        buildConfig = true
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Tez sinash uchun debug kalit bilan imzolanadi
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
}
