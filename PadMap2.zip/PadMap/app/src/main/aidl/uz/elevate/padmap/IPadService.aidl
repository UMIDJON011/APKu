package uz.elevate.padmap;

import uz.elevate.padmap.ICaptureCallback;

interface IPadService {
    // Shizuku UserService uchun majburiy
    void destroy() = 16777114;

    // Gamepadni topib ulaydi. "OK:<nomi>" yoki "ERR:<sabab>" qaytaradi
    String start() = 1;

    // Profil (JSON) va ekran o'lchami (joriy aylanishda)
    void setProfile(String json, int width, int height) = 2;

    void setEnabled(boolean enabled) = 3;

    // mode: 0 = bekor, 1 = tugma, 2 = stik
    void capture(int mode, ICaptureCallback cb) = 4;

    void stop() = 5;
}
