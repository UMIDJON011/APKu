package uz.elevate.padmap;

interface ICaptureCallback {
    oneway void onCaptured(int code);
}
