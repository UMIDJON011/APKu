package uz.elevate.padmap

import android.os.Process
import android.util.Log
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.system.exitProcess

/**
 * Shizuku orqali shell (adb) huquqida ishga tushadigan xizmat.
 * Gamepadni /dev/input dan o'qiydi va ekranga bosishlarni yuboradi.
 */
class PadUserService : IPadService.Stub() {

    private val exec = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var engine: Engine? = null
    @Volatile private var stream: FileInputStream? = null
    private var devName = ""

    private var lastJson: String? = null
    private var lastW = 0
    private var lastH = 0
    private var lastEnabled = true

    override fun destroy() {
        stopInternal()
        exitProcess(0)
    }

    @Synchronized
    override fun start(): String {
        if (engine != null) return "OK:$devName"
        val dev = PadFinder.find()
            ?: return "ERR:Gamepad topilmadi. Qurilmalar: " + PadFinder.lastNames.joinToString(", ").take(200)
        val inj = try { TouchInjector() } catch (t: Throwable) {
            return "ERR:Touch yuborib bo'lmadi: ${t.message}"
        }
        val e = Engine(dev, inj, exec)
        engine = e
        devName = dev.name

        exec.execute {
            lastJson?.let { e.setProfile(Profile.fromJson(it), lastW, lastH) }
            e.enabled = lastEnabled
        }

        thread(name = "pad-reader") {
            try {
                val f = FileInputStream(dev.path)
                stream = f
                val grabbed = Grab.grab(f.fd)
                Log.i("PadMap", "reading ${dev.path} (${dev.name}), grab=$grabbed")
                val size = if (Process.is64Bit()) 24 else 16
                val buf = ByteArray(size * 64)
                val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                while (engine === e) {
                    val n = f.read(buf)
                    if (n <= 0) break
                    var off = 0
                    while (off + size <= n) {
                        val type = bb.getShort(off + size - 8).toInt() and 0xffff
                        val code = bb.getShort(off + size - 6).toInt() and 0xffff
                        val value = bb.getInt(off + size - 4)
                        exec.execute { if (engine === e) e.onRaw(type, code, value) }
                        off += size
                    }
                }
            } catch (t: Throwable) {
                Log.w("PadMap", "reader stopped", t)
            } finally {
                exec.execute { e.releaseAll() }
                synchronized(this) { if (engine === e) engine = null }
            }
        }
        return "OK:${dev.name}"
    }

    override fun setProfile(json: String, width: Int, height: Int) {
        lastJson = json; lastW = width; lastH = height
        val list = Profile.fromJson(json)
        exec.execute { engine?.setProfile(list, width, height) }
    }

    override fun setEnabled(enabled: Boolean) {
        lastEnabled = enabled
        exec.execute {
            engine?.let {
                it.enabled = enabled
                if (!enabled) it.releaseAll()
            }
        }
    }

    override fun capture(mode: Int, cb: ICaptureCallback?) {
        exec.execute {
            val e = engine
            if (e == null) {
                if (mode != 0) try { cb?.onCaptured(-1) } catch (_: Exception) {}
                return@execute
            }
            e.captureMode = mode
            e.captureCb = if (mode == 0) null else cb
        }
    }

    override fun stop() = stopInternal()

    @Synchronized
    private fun stopInternal() {
        val e = engine
        engine = null
        try { stream?.close() } catch (_: Exception) {}   // yopilganda grab ham bo'shaydi
        stream = null
        exec.execute { e?.releaseAll() }
    }
}
