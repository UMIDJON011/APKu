package uz.elevate.padmap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService

/**
 * Shizuku'siz ishlash: Maxsus imkoniyatlar (Accessibility) xizmati.
 * - Gamepad tugmalarini ushlaydi (onKeyEvent) — o'yin ularni ko'rmaydi
 * - Android 14+: analog stiklarni ham ushlaydi (onMotionEvent)
 * - Ekranga multi-touch bosishlarni gesture orqali yuboradi
 */
class PadAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: PadAccessibilityService? = null
            private set
    }

    private val exec: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private lateinit var engine: Engine
    @Volatile private var active = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        engine = Engine(GestureInjector(this, exec), exec)
        instance = this
    }

    override fun onDestroy() {
        instance = null
        exec.shutdownNow()
        super.onDestroy()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    // ---------- OverlayService bilan aloqa ----------

    /** O'yin ochiq (PadMap ishlayapti) bo'lsagina gamepadni ushlaymiz */
    fun setActive(on: Boolean) {
        active = on
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val info = serviceInfo
                info.setMotionEventSources(if (on) InputDevice.SOURCE_JOYSTICK else 0)
                serviceInfo = info
            } catch (_: Throwable) {
            }
        }
        if (!on) exec.execute { engine.releaseAll() }
    }

    fun setProfile(list: List<Mapping>, w: Int, h: Int) = exec.execute { engine.setProfile(list, w, h) }

    fun setEnabled(on: Boolean) = exec.execute {
        engine.enabled = on
        if (!on) engine.releaseAll()
    }

    fun capture(mode: Int, cb: ((Int) -> Unit)?) = exec.execute {
        engine.captureMode = mode
        engine.captureCb = if (mode == 0) null else cb
    }

    // ---------- kirish ----------

    override fun onKeyEvent(e: KeyEvent): Boolean {
        if (!active) return false
        val s = e.source
        val isPad = KeyEvent.isGamepadButton(e.keyCode) ||
            (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!isPad) return false
        if (e.repeatCount > 0) return true
        val c = Codes.fromKeyCode(e.keyCode).let { if (it < 0) 3000 + e.keyCode else it }
        val down = e.action == KeyEvent.ACTION_DOWN
        exec.execute { engine.onKey(c, down) }
        return true // o'yinga o'tkazmaymiz (B → "orqaga" bo'lib qolmasin)
    }

    override fun onMotionEvent(e: MotionEvent) {
        if (!active) return
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return
        val v = FloatArray(12)
        v[0] = e.getAxisValue(MotionEvent.AXIS_X)
        v[1] = e.getAxisValue(MotionEvent.AXIS_Y)
        v[2] = e.getAxisValue(MotionEvent.AXIS_Z)
        v[3] = e.getAxisValue(MotionEvent.AXIS_RX)
        v[4] = e.getAxisValue(MotionEvent.AXIS_RY)
        v[5] = e.getAxisValue(MotionEvent.AXIS_RZ)
        v[6] = maxOf(e.getAxisValue(MotionEvent.AXIS_GAS), e.getAxisValue(MotionEvent.AXIS_RTRIGGER))
        v[7] = maxOf(e.getAxisValue(MotionEvent.AXIS_BRAKE), e.getAxisValue(MotionEvent.AXIS_LTRIGGER))
        v[8] = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        v[9] = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        exec.execute {
            for (i in 0..5) engine.onAxis(i, v[i])
            engine.onAxis(9, v[6])
            engine.onAxis(10, v[7])
            engine.onAxis(0x10, v[8])
            engine.onAxis(0x11, v[9])
            engine.sync()
        }
    }
}

/**
 * Accessibility gesture orqali multi-touch.
 * Har o'zgarishda barcha faol barmoqlar bitta gesture'da davom ettiriladi (continueStroke).
 */
class GestureInjector(
    private val svc: AccessibilityService,
    private val exec: ScheduledExecutorService,
) : Injector {

    private class P(val id: Int, var x: Float, var y: Float) {
        var lx = x
        var ly = y
        var stroke: GestureDescription.StrokeDescription? = null
        var up = false
    }

    private val ptrs = ArrayList<P>()
    private var busy = false
    private var pending = false

    override fun down(x: Float, y: Float): Int {
        val id = (0..9).firstOrNull { i -> ptrs.none { it.id == i } } ?: return -1
        ptrs.add(P(id, x.coerceAtLeast(0f), y.coerceAtLeast(0f)))
        request()
        return id
    }

    override fun move(id: Int, x: Float, y: Float) {
        val p = ptrs.find { it.id == id && !it.up } ?: return
        p.x = x.coerceAtLeast(0f); p.y = y.coerceAtLeast(0f)
        request()
    }

    override fun up(id: Int) {
        val p = ptrs.find { it.id == id && !it.up } ?: return
        p.up = true
        request()
    }

    override fun releaseAll() {
        if (ptrs.isEmpty()) return
        ptrs.forEach { it.up = true }
        request()
    }

    private fun request() {
        if (busy) { pending = true; return }
        flush()
    }

    private fun flush() {
        pending = false
        if (ptrs.isEmpty()) return
        val b = GestureDescription.Builder()
        val sent = ArrayList<Pair<P, GestureDescription.StrokeDescription>>()
        for (p in ptrs) {
            val path = Path().apply { moveTo(p.lx, p.ly); lineTo(p.x, p.y) }
            val prev = p.stroke
            val s = try {
                if (prev == null) GestureDescription.StrokeDescription(path, 0, 16, !p.up)
                else prev.continueStroke(path, 0, 16, !p.up)
            } catch (_: Exception) {
                GestureDescription.StrokeDescription(path, 0, 16, !p.up)
            }
            b.addStroke(s)
            sent.add(p to s)
            p.lx = p.x; p.ly = p.y
        }
        for ((p, s) in sent) p.stroke = s
        ptrs.removeAll { it.up }

        busy = true
        val ok = try {
            svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) {
                    exec.execute { busy = false; if (pending) flush() }
                }

                override fun onCancelled(g: GestureDescription?) {
                    exec.execute {
                        busy = false
                        // Gesture uzildi (masalan ekranga qo'l tegdi) — barmoqlarni qaytadan bosamiz
                        ptrs.forEach { it.stroke = null }
                        if (ptrs.isNotEmpty() || pending) flush()
                    }
                }
            }, null)
        } catch (_: Exception) { false }
        if (!ok) {
            busy = false
            ptrs.forEach { it.stroke = null }
        }
    }
}
