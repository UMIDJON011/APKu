package uz.elevate.padmap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.InputDevice
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "uz.elevate.padmap.STOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var editor: EditorView? = null
    private var hud: HudView? = null
    private var pkg = ""
    var maps: MutableList<Mapping> = mutableListOf()
        private set

    /** Ekranga chiqadigan holat */
    var accState = "…"
        private set
    var padState = "…"
        private set
    private var lastToast = ""
    private var wasAcc = false

    private val acc get() = PadAccessibilityService.instance

    /** Har 2 soniyada: maxsus imkoniyat xizmati va gamepadni tekshirish */
    private val keeper = object : Runnable {
        override fun run() {
            val a = acc
            val newAcc = if (a != null) "✅ Xizmat yoqilgan" else "❌ PadMap maxsus imkoniyatini yoqing"
            if (a != null && !wasAcc) { a.setActive(true); applyProfile(editor == null) }
            wasAcc = a != null
            if (newAcc != accState) { accState = newAcc; editor?.updateInfo(); toastOnce(newAcc) }
            val pads = padNames()
            val newPad = if (pads.isNotEmpty()) "🎮 ${pads.joinToString()}" else "❌ Gamepad ulanmagan"
            if (newPad != padState) { padState = newPad; editor?.updateInfo(); toastOnce(newPad) }
            main.postDelayed(this, 2000)
        }
    }

    private fun padNames(): List<String> = InputDevice.getDeviceIds().toList().mapNotNull { id: Int ->
        val dev = InputDevice.getDevice(id) ?: return@mapNotNull null
        val s = dev.sources
        val isPad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isPad && !dev.isVirtual) dev.name else null
    }.distinct()

    private fun toastOnce(s: String) {
        if (s != lastToast) { lastToast = s; toast(s) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startForegroundCompat()
        val newPkg = intent?.getStringExtra(EXTRA_PKG) ?: pkg
        if (newPkg != pkg) {
            pkg = newPkg
            closeEditor(false)
            maps = Profile.load(this, pkg)
        }
        showBubble()
        showHud()
        main.removeCallbacks(keeper)
        main.post(keeper)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("padmap", "PadMap", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "padmap")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("PadMap ishlayapti")
            .setContentText("Gamepad → ekran")
            .addAction(Notification.Action.Builder(null, "To'xtatish", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    fun reconnect() {
        lastToast = ""; accState = "…"; padState = "…"; wasAcc = false
        main.removeCallbacks(keeper); main.post(keeper)
    }

    fun applyProfile(enable: Boolean) {
        hud?.invalidate()
        val a = acc ?: return
        val sz = screenSize()
        a.setProfile(maps.toList(), sz.x, sz.y)
        a.setEnabled(enable)
    }

    /** Gamepad tugmasini kutish (xizmat orqali). Xizmat o'chiq bo'lsa — tahrirlash oynasi o'zi ushlaydi. */
    fun capture(mode: Int, cb: (Int) -> Unit) {
        acc?.capture(mode) { code -> main.post { cb(code) } }
    }

    fun cancelCapture() {
        acc?.capture(0, null)
    }

    fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else Point().also {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(it)
        }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.postDelayed({ applyProfile(editor == null) }, 300)
    }

    // ---------------- oynalar ----------------

    private fun overlayParams(w: Int, h: Int, flags: Int) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    var hudOn: Boolean
        get() = getSharedPreferences("ui", MODE_PRIVATE).getBoolean("hud", true)
        set(v) {
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("hud", v).apply()
        }

    private fun showHud() {
        if (hud != null || !hudOn) return
        val v = HudView(this)
        val lp = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply { alpha = 0.6f } // Android 12+: 0.8 dan shaffofroq bo'lsa bosishlar o'yinga o'tadi
        wm.addView(v, lp)
        hud = v
        if (editor != null) v.visibility = View.GONE
    }

    private fun hideHud() {
        hud?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hud = null
    }

    fun toggleHud(): Boolean {
        hudOn = !hudOn
        if (hudOn) showHud() else hideHud()
        return hudOn
    }

    private fun showBubble() {
        if (bubble != null) return
        val d = resources.displayMetrics.density
        val size = (44 * d).toInt()
        val v = TextView(this).apply {
            text = "🎮"; textSize = 18f; gravity = Gravity.CENTER; alpha = 0.75f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6161A22.toInt())
                setStroke((2 * d).toInt(), 0xFF2979FF.toInt())
            }
        }
        val lp = overlayParams(size, size, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
            .apply { x = (8 * d).toInt(); y = (120 * d).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) openEditor()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    fun openEditor() {
        if (editor != null) return
        acc?.setEnabled(false)
        val ed = EditorView(this)
        // Fokusli oyna: gamepad tugmalarini Shizuku'siz ham ushlay oladi
        wm.addView(ed, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0))
        editor = ed
        ed.requestFocus()
        bubble?.visibility = View.GONE
        hud?.visibility = View.GONE
    }

    fun closeEditor(save: Boolean) {
        val ed = editor ?: return
        cancelCapture()
        try { wm.removeView(ed) } catch (_: Exception) {}
        editor = null
        bubble?.visibility = View.VISIBLE
        hud?.visibility = View.VISIBLE
        if (save) {
            Profile.save(this, pkg, maps); toast("Saqlandi")
        } else {
            maps = Profile.load(this, pkg)
        }
        applyProfile(true)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        main.removeCallbacks(keeper)
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hideHud()
        editor = null; bubble = null
        acc?.setActive(false)
        super.onDestroy()
    }
}
