package uz.elevate.padmap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val EXTRA_PKG = "pkg"
        const val ACTION_STOP = "uz.elevate.padmap.STOP"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var editor: EditorView? = null
    private var hud: HudView? = null
    private var pkg = ""
    var maps: MutableList<Mapping> = mutableListOf()
        private set

    private var pad: IPadService? = null
    private var bound = false
    private var bindTime = 0L

    /** Ekranga chiqadigan holat: Shizuku va gamepad */
    var shizukuState = "…"
        private set
    var padState = "…"
        private set
    private var lastToast = ""

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, PadUserService::class.java.name))
            .tag("padmap")
            .daemon(false)
            .processNameSuffix("pad")
            .debuggable(false)
            .version(BuildConfig.VERSION_CODE)
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, b: IBinder?) {
            if (b != null && b.pingBinder()) {
                pad = IPadService.Stub.asInterface(b)
                setShizuku("✅ Shizuku")
                connectPad()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            pad = null
            bound = false
            setShizuku("❌ Shizuku xizmati to'xtadi")
        }
    }

    private val binderListener = Shizuku.OnBinderReceivedListener { main.post { bindPad() } }

    /** Har 4 soniyada: Shizuku'ga ulanish va gamepadni tekshirish */
    private val keeper = object : Runnable {
        override fun run() {
            if (pad == null) {
                if (bound && SystemClock.uptimeMillis() - bindTime > 12000) {
                    try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
                    bound = false
                    setShizuku("❌ Shizuku xizmati ishga tushmadi — qayta urinilmoqda")
                }
                bindPad()
            } else {
                connectPad()
            }
            main.postDelayed(this, 4000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Shizuku.addBinderReceivedListenerSticky(binderListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf(); return START_NOT_STICKY
        }
        startForegroundCompat()
        val newPkg = intent?.getStringExtra(EXTRA_PKG) ?: pkg
        if (newPkg != pkg) {
            pkg = newPkg
            closeEditor(false)
            maps = Profile.load(this, pkg)
        }
        showBubble()
        showHud()
        main.removeCallbacks(keeper)
        main.post(keeper)
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("padmap", "PadMap", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "padmap")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("PadMap ishlayapti")
            .setContentText("Gamepad → ekran")
            .addAction(Notification.Action.Builder(null, "To'xtatish", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(7, n)
    }

    // ---------------- holat ----------------

    private fun setShizuku(s: String) {
        shizukuState = s
        editor?.updateInfo()
        if (s.startsWith("❌")) toastOnce(s)
    }

    private fun setPad(s: String) {
        padState = s
        editor?.updateInfo()
        toastOnce(s)
    }

    private fun toastOnce(s: String) {
        if (s != lastToast) { lastToast = s; toast(s) }
    }

    // ---------------- Shizuku ----------------

    private fun bindPad() {
        if (pad != null || bound) return
        try {
            if (!Shizuku.pingBinder()) {
                setShizuku("❌ Shizuku topilmadi — Shizuku ilovasida Start bosing")
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                setShizuku("❌ Shizuku ruxsati yo'q — PadMap'ni ochib ruxsat bering")
                return
            }
            setShizuku("⏳ Shizuku ulanmoqda…")
            bound = true
            bindTime = SystemClock.uptimeMillis()
            Shizuku.bindUserService(args, conn)
        } catch (t: Throwable) {
            bound = false
            setShizuku("❌ Shizuku xatosi: ${t.message}")
        }
    }

    private fun connectPad() {
        val p = pad ?: return
        thread {
            val r = try { p.start() } catch (t: Throwable) { "ERR:${t.message}" }
            main.post {
                val s = if (r.startsWith("OK:")) "🎮 ${r.removePrefix("OK:")}" else "❌ ${r.removePrefix("ERR:")}"
                if (s != padState) {
                    setPad(s)
                    applyProfile(editor == null)
                }
            }
        }
    }

    fun reconnect() {
        lastToast = ""
        padState = "…"
        try { pad?.stop() } catch (_: Exception) {}
        if (pad == null) {
            if (bound) try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
            bound = false
            bindPad()
        } else connectPad()
    }

    fun applyProfile(enable: Boolean) {
        hud?.invalidate()
        val p = pad ?: return
        val s = screenSize()
        try {
            p.setProfile(Profile.toJson(maps), s.x, s.y)
            p.setEnabled(enable)
        } catch (_: Exception) {
        }
    }

    /** Shizuku orqali tugma tanlash. Shizuku bo'lmasa — hech narsa qilmaydi (tahrirlash oynasi o'zi ushlaydi). */
    fun capture(mode: Int, cb: (Int) -> Unit) {
        val p = pad ?: return
        try {
            p.capture(mode, object : ICaptureCallback.Stub() {
                override fun onCaptured(code: Int) { main.post { cb(code) } }
            })
        } catch (_: Exception) {
        }
    }

    fun cancelCapture() {
        try { pad?.capture(0, null) } catch (_: Exception) {}
    }

    fun screenSize(): Point =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else Point().also {
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealSize(it)
        }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.postDelayed({ applyProfile(editor == null) }, 300)
    }

    // ---------------- oynalar ----------------

    private fun overlayParams(w: Int, h: Int, flags: Int) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

    var hudOn: Boolean
        get() = getSharedPreferences("ui", MODE_PRIVATE).getBoolean("hud", true)
        set(v) {
            getSharedPreferences("ui", MODE_PRIVATE).edit().putBoolean("hud", v).apply()
        }

    private fun showHud() {
        if (hud != null || !hudOn) return
        val v = HudView(this)
        val lp = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        ).apply { alpha = 0.6f } // Android 12+: 0.8 dan shaffofroq bo'lsa bosishlar o'yinga o'tadi
        wm.addView(v, lp)
        hud = v
        if (editor != null) v.visibility = View.GONE
    }

    private fun hideHud() {
        hud?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hud = null
    }

    fun toggleHud(): Boolean {
        hudOn = !hudOn
        if (hudOn) showHud() else hideHud()
        return hudOn
    }

    private fun showBubble() {
        if (bubble != null) return
        val d = resources.displayMetrics.density
        val size = (44 * d).toInt()
        val v = TextView(this).apply {
            text = "🎮"; textSize = 18f; gravity = Gravity.CENTER; alpha = 0.75f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE6161A22.toInt())
                setStroke((2 * d).toInt(), 0xFF2979FF.toInt())
            }
        }
        val lp = overlayParams(size, size, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE)
            .apply { x = (8 * d).toInt(); y = (120 * d).toInt() }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 10 * d || abs(dy) > 10 * d) moved = true
                    if (moved) { lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) openEditor()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    fun openEditor() {
        if (editor != null) return
        try { pad?.setEnabled(false) } catch (_: Exception) {}
        val ed = EditorView(this)
        // Fokusli oyna: gamepad tugmalarini Shizuku'siz ham ushlay oladi
        wm.addView(ed, overlayParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, 0))
        editor = ed
        ed.requestFocus()
        bubble?.visibility = View.GONE
        hud?.visibility = View.GONE
    }

    fun closeEditor(save: Boolean) {
        val ed = editor ?: return
        cancelCapture()
        try { wm.removeView(ed) } catch (_: Exception) {}
        editor = null
        bubble?.visibility = View.VISIBLE
        hud?.visibility = View.VISIBLE
        if (save) {
            Profile.save(this, pkg, maps); toast("Saqlandi")
        } else {
            maps = Profile.load(this, pkg)
        }
        applyProfile(true)
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        main.removeCallbacks(keeper)
        Shizuku.removeBinderReceivedListener(binderListener)
        editor?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        hideHud()
        editor = null; bubble = null
        try { pad?.stop() } catch (_: Exception) {}
        if (bound) try { Shizuku.unbindUserService(args, conn, true) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
