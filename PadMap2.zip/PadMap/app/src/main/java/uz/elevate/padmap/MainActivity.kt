package uz.elevate.padmap

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import android.hardware.input.InputManager
import android.view.InputDevice
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private class AppItem(val label: String, val pkg: String, val icon: Drawable)

    private val bg = 0xFF0E1116.toInt()
    private val card = 0xFF1A1F27.toInt()
    private val accent = 0xFF2979FF.toInt()

    private lateinit var stOverlay: TextView
    private lateinit var stShizuku: TextView
    private lateinit var stPad: TextView
    private lateinit var im: InputManager
    private val padListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(id: Int) = runOnUiThread { refresh() }
        override fun onInputDeviceRemoved(id: Int) = runOnUiThread { refresh() }
        override fun onInputDeviceChanged(id: Int) = runOnUiThread { refresh() }
    }
    private lateinit var btnOverlay: TextView
    private lateinit var btnShizuku: TextView
    private lateinit var btnRestricted: TextView
    private val apps = ArrayList<AppItem>()
    private lateinit var adapter: BaseAdapter
    private lateinit var bt: BtPair
    private var d = 1f


    private fun round(color: Int, r: Float = 14f) = GradientDrawable().apply { cornerRadius = r * d; setColor(color) }

    private fun pill(text: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
        background = round(color, 12f)
        setOnClickListener { onClick() }
    }

    private fun lp(top: Int = 8) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = (top * d).toInt() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        d = resources.displayMetrics.density
        window.statusBarColor = bg
        window.navigationBarColor = bg
        bt = BtPair(this)
        im = getSystemService(InputManager::class.java)
        im.registerInputDeviceListener(padListener, null)
        val p = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(p, p, p, 0)
        }

        root.addView(TextView(this).apply {
            text = "🎮 PadMap"
            setTextColor(Color.WHITE); textSize = 28f; typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Bepul gamepad keymapper • FC Mobile uchun"
            setTextColor(0xFF8B95A5.toInt()); textSize = 14f
        })

        // Holat kartasi
        val st = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = round(card)
            setPadding(p, p, p, p)
        }
        stOverlay = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f }
        stShizuku = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, (6 * d).toInt(), 0, 0) }
        stPad = TextView(this).apply { setTextColor(Color.WHITE); textSize = 15f; setPadding(0, (6 * d).toInt(), 0, 0) }
        st.addView(stOverlay); st.addView(stShizuku); st.addView(stPad)
        btnOverlay = pill("Ekran ustida ko'rsatishga ruxsat", 0xFF37474F.toInt()) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnShizuku = pill("Maxsus imkoniyatlarda PadMap'ni yoqish", 0xFF37474F.toInt()) {
            toast("Ro'yxatdan PadMap'ni topib yoqing")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnRestricted = pill("Yoqib bo'lmasa: Cheklangan sozlamalarga ruxsat", 0xFF263238.toInt()) {
            toast("⋮ (yuqori o'ngda) → \"Cheklangan sozlamalarga ruxsat berish\"")
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
        st.addView(btnOverlay, lp(12))
        st.addView(btnShizuku, lp(8))
        st.addView(btnRestricted, lp(8))
        root.addView(st, lp(16))

        root.addView(pill("🎮  Gamepadni ulash (Bluetooth)", accent) { bt.show() }, lp(12))

        root.addView(TextView(this).apply {
            text = "O'YINNI TANLANG"
            setTextColor(0xFF8B95A5.toInt()); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.1f
        }, lp(20))

        val list = ListView(this).apply {
            divider = null
            setBackgroundColor(Color.TRANSPARENT)
        }
        adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, cv: View?, parent: ViewGroup?): View {
                val row = (cv as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = round(card, 12f)
                    setPadding((12 * d).toInt(), (10 * d).toInt(), (12 * d).toInt(), (10 * d).toInt())
                    layoutParams = android.widget.AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    addView(ImageView(context), LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt()))
                    addView(TextView(context).apply {
                        setTextColor(Color.WHITE); textSize = 16f; setPadding((14 * d).toInt(), 0, 0, 0)
                    })
                }
                (row.getChildAt(0) as ImageView).setImageDrawable(apps[i].icon)
                (row.getChildAt(1) as TextView).text = apps[i].label
                return row
            }
        }
        list.adapter = adapter
        list.dividerHeight = (6 * d).toInt()
        list.divider = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        list.setOnItemClickListener { _, _, i, _ -> launch(apps[i]) }
        root.addView(list, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = (8 * d).toInt()
        })
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 2)
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        bt.release()
        im.unregisterInputDeviceListener(padListener)
        super.onDestroy()
    }

    private fun accOk(): Boolean {
        if (PadAccessibilityService.instance != null) return true
        val list = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val full = "$packageName/${PadAccessibilityService::class.java.name}"
        val short = "$packageName/.PadAccessibilityService"
        return list.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    /** Ulangan gamepadlar nomi (tizim ko'rgan) */
    private fun pads(): List<String> = InputDevice.getDeviceIds().toList().mapNotNull { id: Int ->
        val dev = InputDevice.getDevice(id) ?: return@mapNotNull null
        val s = dev.sources
        val isPad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isPad && !dev.isVirtual) dev.name else null
    }.distinct()

    private fun refresh() {
        val ps = pads()
        stPad.text = if (ps.isNotEmpty()) "✅  Gamepad: ${ps.joinToString()}" else "❌  Gamepad ulanmagan — pastdagi tugma orqali ulang"
        val overlay = Settings.canDrawOverlays(this)
        val acc = accOk()
        stOverlay.text = if (overlay) "✅  Ekran ustida ko'rsatish" else "❌  Ekran ustida ko'rsatish ruxsati yo'q"
        stShizuku.text = if (acc) "✅  Maxsus imkoniyat (PadMap xizmati) yoqilgan" else "❌  Maxsus imkoniyat o'chiq"
        btnOverlay.visibility = if (overlay) View.GONE else View.VISIBLE
        btnShizuku.visibility = if (acc) View.GONE else View.VISIBLE
        btnRestricted.visibility = if (acc) View.GONE else View.VISIBLE
    }

    private fun loadApps() {
        thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val res = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .distinctBy { it.pkg }
                .sortedWith(compareBy({ !it.pkg.contains("fc", true) && !it.pkg.contains("ea.gp", true) }, { it.label.lowercase() }))
            runOnUiThread {
                apps.clear(); apps.addAll(res); adapter.notifyDataSetChanged()
            }
        }
    }

    private fun launch(a: AppItem) {
        if (!Settings.canDrawOverlays(this)) { toast("Avval ekran ustida ko'rsatish ruxsatini bering"); return }
        if (!accOk()) { toast("Avval Maxsus imkoniyatlarda PadMap'ni yoqing"); return }
        startForegroundService(Intent(this, OverlayService::class.java).putExtra(OverlayService.EXTRA_PKG, a.pkg))
        val li = packageManager.getLaunchIntentForPackage(a.pkg)
        if (li != null) startActivity(li) else toast("Ilovani ochib bo'lmadi")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
