package uz.elevate.padmap

import android.hardware.input.InputManager
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import java.io.FileDescriptor
import java.lang.reflect.Method
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/* Bu fayldagi hamma narsa Shizuku jarayonida (shell huquqi bilan) ishlaydi. */

private const val TAG = "PadMap"

/** Ekranga ko'p barmoqli (multi-touch) bosishlarni yuboradi. */
class TouchInjector {
    private val target: Any
    private val inject: Method

    init {
        var t: Any
        var m: Method
        try {
            // Android 14+
            val c = Class.forName("android.hardware.input.InputManagerGlobal")
            t = c.getDeclaredMethod("getInstance").invoke(null)!!
            m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        } catch (e: Throwable) {
            val c = InputManager::class.java
            t = c.getDeclaredMethod("getInstance").invoke(null)!!
            m = c.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
        }
        target = t
        inject = m
    }

    private class P(val id: Int, var x: Float, var y: Float)

    private val ptrs = ArrayList<P>()
    private var downTime = 0L

    fun down(x: Float, y: Float): Int {
        val id = (0..9).firstOrNull { i -> ptrs.none { it.id == i } } ?: return -1
        ptrs.add(P(id, x, y))
        val idx = ptrs.size - 1
        val now = SystemClock.uptimeMillis()
        if (ptrs.size == 1) {
            downTime = now
            send(MotionEvent.ACTION_DOWN, now)
        } else {
            send(MotionEvent.ACTION_POINTER_DOWN or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT), now)
        }
        return id
    }

    fun move(id: Int, x: Float, y: Float) {
        val p = ptrs.find { it.id == id } ?: return
        p.x = x; p.y = y
        send(MotionEvent.ACTION_MOVE, SystemClock.uptimeMillis())
    }

    fun up(id: Int) {
        val idx = ptrs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val action = if (ptrs.size == 1) MotionEvent.ACTION_UP
        else MotionEvent.ACTION_POINTER_UP or (idx shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        send(action, SystemClock.uptimeMillis())
        ptrs.removeAt(idx)
    }

    fun releaseAll() {
        while (ptrs.isNotEmpty()) up(ptrs.last().id)
    }

    private fun send(action: Int, now: Long) {
        val n = ptrs.size
        val props = Array(n) {
            MotionEvent.PointerProperties().apply {
                id = ptrs[it].id
                toolType = MotionEvent.TOOL_TYPE_FINGER
            }
        }
        val coords = Array(n) {
            MotionEvent.PointerCoords().apply {
                x = ptrs[it].x; y = ptrs[it].y
                pressure = 1f; size = 1f
            }
        }
        val ev = MotionEvent.obtain(
            downTime, now, action, n, props, coords,
            0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0
        )
        try {
            inject.invoke(target, ev, 0) // 0 = ASYNC
        } catch (e: Throwable) {
            Log.w(TAG, "inject failed", e)
        }
        ev.recycle()
    }
}

class PadDevice(val path: String, val name: String) {
    val min = IntArray(64)
    val max = IntArray(64)
    val rest = IntArray(64)
}

/** `getevent -p` chiqishidan gamepadni topadi. */
object PadFinder {
    /** Oxirgi qidiruvda topilgan barcha kiritish qurilmalari (xato xabari uchun) */
    var lastNames: List<String> = emptyList()
    private val header = Regex("""^\s+([A-Z]+)\s*\(([0-9a-f]{4})\):(.*)$""")
    private val absRe = Regex("""([0-9a-f]{4})\s*:\s*value (-?\d+), min (-?\d+), max (-?\d+)""")

    fun find(): PadDevice? {
        val out = try {
            val p = Runtime.getRuntime().exec(arrayOf("getevent", "-p"))
            val s = p.inputStream.bufferedReader().readText()
            p.waitFor()
            s
        } catch (e: Exception) {
            Log.w(TAG, "getevent failed", e); return null
        }

        class Blk(val path: String) {
            var name = ""
            val keys = HashSet<Int>()
            val dev = PadDevice(path, "")
            val abs = HashSet<Int>()
        }

        val blocks = ArrayList<Blk>()
        var cur: Blk? = null
        var section = ""
        for (line in out.lines()) {
            if (line.startsWith("add device")) {
                cur = Blk(line.substringAfter(": ").trim()).also { blocks.add(it) }
                section = ""
                continue
            }
            val b = cur ?: continue
            val t = line.trim()
            if (t.startsWith("name:")) {
                b.name = t.substringAfter("\"").substringBeforeLast("\""); continue
            }
            if (t.startsWith("input props")) { section = ""; continue }
            var body = line
            val h = header.find(line)
            if (h != null) {
                section = h.groupValues[1]
                body = h.groupValues[3]
            }
            when (section) {
                "KEY" -> body.trim().split(Regex("\\s+")).forEach { tok ->
                    tok.toIntOrNull(16)?.let { b.keys.add(it) }
                }
                "ABS" -> absRe.find(body)?.let { m ->
                    val code = m.groupValues[1].toInt(16)
                    if (code < 64) {
                        b.abs.add(code)
                        b.dev.rest[code] = m.groupValues[2].toInt()
                        b.dev.min[code] = m.groupValues[3].toInt()
                        b.dev.max[code] = m.groupValues[4].toInt()
                    }
                }
            }
        }

        lastNames = blocks.map { it.name }.filter { it.isNotBlank() }
        fun score(b: Blk): Int {
            if (0x35 in b.abs) return 0                                  // sensorli ekran
            var s = 0
            if (b.keys.any { it in 0x130..0x13e }) s += 10               // BTN_GAMEPAD
            if (b.keys.any { it in 0x120..0x12f }) s += 5                // BTN_JOYSTICK
            if (0 in b.abs && 1 in b.abs) s += 3
            if (2 in b.abs || 5 in b.abs || 3 in b.abs) s += 2
            if (0x10 in b.abs) s += 1
            val n = b.name.lowercase()
            if (listOf("pad", "controller", "joy", "xbox", "wireless", "dualshock", "dualsense", "8bitdo")
                    .any { n.contains(it) }) s += 4
            return if (s >= 5) s else 0
        }
        val best = blocks.maxByOrNull { score(it) }?.takeIf { score(it) > 0 } ?: return null
        val d = PadDevice(best.path, best.name)
        for (i in 0 until 64) {
            d.min[i] = best.dev.min[i]; d.max[i] = best.dev.max[i]; d.rest[i] = best.dev.rest[i]
        }
        return d
    }
}

/** EVIOCGRAB – gamepadni faqat o'zimizga olamiz, shunda o'yin/tizim uni ko'rmaydi
 *  (masalan B tugmasi "Orqaga" bo'lib o'yindan chiqarib yubormaydi). */
object Grab {
    private const val EVIOCGRAB = 0x40044590

    fun grab(fd: FileDescriptor): Boolean {
        return try {
            val os = Class.forName("libcore.io.Libcore").getField("os").get(null)!!
            try {
                val m = os.javaClass.getMethod("ioctlInt", FileDescriptor::class.java, Int::class.javaPrimitiveType)
                m.invoke(os, fd, EVIOCGRAB)
            } catch (e: NoSuchMethodException) {
                val refC = Class.forName("android.system.Int32Ref")
                val ref = refC.getConstructor(Int::class.javaPrimitiveType).newInstance(1)
                val m = os.javaClass.getMethod("ioctlInt", FileDescriptor::class.java, Int::class.javaPrimitiveType, refC)
                m.invoke(os, fd, EVIOCGRAB, ref)
            }
            true
        } catch (t: Throwable) {
            Log.w(TAG, "EVIOCGRAB failed", t); false
        }
    }
}

/** Gamepad hodisalarini ekran bosishlariga aylantiradi. Faqat bitta (exec) oqimda ishlaydi. */
class Engine(
    private val dev: PadDevice,
    private val inj: TouchInjector,
    private val exec: ScheduledExecutorService,
) {
    var enabled = true
    var captureMode = 0
    var captureCb: ICaptureCallback? = null

    private var maps: List<Mapping> = emptyList()
    private var W = 2400f
    private var H = 1080f

    private val held = HashSet<Int>()
    private val active = HashMap<Int, Act>()
    private val swipes = HashSet<SwipeAct>()
    private val absVal = dev.rest.copyOf()
    private val absBtn = BooleanArray(64)
    private val stickPtr = HashMap<Mapping, Int>()
    private val lastVec = HashMap<Mapping, Pair<Float, Float>>()

    fun setProfile(list: List<Mapping>, w: Int, h: Int) {
        releaseAll()
        maps = list
        W = w.toFloat(); H = h.toFloat()
    }

    fun releaseAll() {
        swipes.forEach { it.cancel() }
        swipes.clear()
        active.clear()
        stickPtr.clear()
        lastVec.clear()
        inj.releaseAll()
    }

    private fun px(f: Float) = f * W
    private fun py(f: Float) = f * H
    private fun rad(m: Mapping) = m.r * min(W, H)

    // ---------- kiruvchi hodisalar ----------

    fun onRaw(type: Int, code: Int, value: Int) {
        when (type) {
            1 -> if (value != 2) keyEvent(code, value == 1)           // EV_KEY
            3 -> {                                                    // EV_ABS
                if (code >= 64) return
                absVal[code] = value
                when (code) {
                    0x10 -> hat(Codes.HAT_LEFT, Codes.HAT_RIGHT, value)
                    0x11 -> hat(Codes.HAT_UP, Codes.HAT_DOWN, value)
                    else -> {
                        if (captureMode == 2) captureStick(code)
                        absButton(code)
                    }
                }
            }
            0 -> updateSticks()                                        // EV_SYN
        }
    }

    private fun hat(neg: Int, pos: Int, v: Int) {
        if (v < 0) { keyEvent(pos, false); keyEvent(neg, true) }
        else if (v > 0) { keyEvent(neg, false); keyEvent(pos, true) }
        else { keyEvent(neg, false); keyEvent(pos, false) }
    }

    private fun norm(code: Int): Float {
        val range = (dev.max[code] - dev.min[code]).toFloat()
        if (range <= 0f) return 0f
        val c = (dev.max[code] + dev.min[code]) / 2f
        return ((absVal[code] - c) / (range / 2f)).coerceIn(-1f, 1f)
    }

    /** Trigger kabi o'qlarni tugma sifatida ishlatish */
    private fun absButton(code: Int) {
        if (maps.any { it.type == MType.STICK && (it.ax == code || it.ay == code) }) return
        val range = (dev.max[code] - dev.min[code]).toFloat()
        if (range <= 0f) return
        val m = abs(absVal[code] - dev.rest[code]) / range
        if (!absBtn[code] && m > 0.4f) { absBtn[code] = true; keyEvent(Codes.ABS_BTN + code, true) }
        else if (absBtn[code] && m < 0.25f) { absBtn[code] = false; keyEvent(Codes.ABS_BTN + code, false) }
    }

    private fun captureStick(code: Int) {
        if (abs(norm(code)) < 0.6f) return
        val pair = when (code) {
            0, 1 -> 0 to 1
            3, 4 -> 3 to 4
            2, 5 -> 2 to 5
            else -> return
        }
        finishCapture(pair.first or (pair.second shl 16))
    }

    private fun finishCapture(code: Int) {
        val cb = captureCb
        captureMode = 0
        captureCb = null
        try { cb?.onCaptured(code) } catch (_: Exception) {}
    }

    private fun keyEvent(code: Int, down: Boolean) {
        if (down) { if (!held.add(code)) return } else { if (!held.remove(code)) return }

        if (captureMode == 1 && down) { finishCapture(code); return }
        if (!enabled) return

        for (m in maps) {
            if (m.type == MType.DPAD && (code == m.up || code == m.down || code == m.left || code == m.right)) {
                updateDpad(m)
            }
        }

        if (down) {
            val isAct = { m: Mapping -> m.type == MType.TAP || m.type == MType.SWIPE }
            // Avval kombinatsiya (mod bosib turilgan bo'lsa), keyin oddiy bog'lanish
            val m = maps.firstOrNull { isAct(it) && it.key == code && it.mod != 0 && it.mod in held }
                ?: maps.firstOrNull { isAct(it) && it.key == code && it.mod == 0 }
                ?: return
            active.remove(code)?.end()
            active[code] = if (m.type == MType.TAP) TapAct(m) else SwipeAct(m)
        } else {
            active.remove(code)?.end()
        }
    }

    // ---------- harakatlar ----------

    private abstract inner class Act { abstract fun end() }

    private inner class TapAct(m: Mapping) : Act() {
        val id = inj.down(px(m.x), py(m.y))
        override fun end() { if (id >= 0) inj.up(id) }
    }

    /** Bosib, ma'lum vaqt ichida surish (FC Mobile: shoot'ni bosib pastga tortish) */
    private inner class SwipeAct(private val m: Mapping) : Act() {
        private val id = inj.down(px(m.x), py(m.y))
        private val steps = max(1, m.ms / 16)
        private var step = 0
        private var released = false
        private var done = false
        private var fut: ScheduledFuture<*>? = null

        init {
            if (id >= 0) {
                swipes.add(this)
                fut = exec.scheduleAtFixedRate({ tick() }, 16, 16, TimeUnit.MILLISECONDS)
            }
        }

        private fun tick() {
            step++
            val t = (step.toFloat() / steps).coerceAtMost(1f)
            inj.move(id, px(m.x + (m.x2 - m.x) * t), py(m.y + (m.y2 - m.y) * t))
            if (step >= steps) {
                fut?.cancel(false)
                done = true
                if (released) { inj.up(id); swipes.remove(this) }
            }
        }

        override fun end() {
            released = true
            if (id < 0) return
            // Tez bosilsa ham surish oxirigacha bajariladi, keyin qo'yib yuboriladi
            if (done) { inj.up(id); swipes.remove(this) }
        }

        fun cancel() { fut?.cancel(false) }
    }

    private fun updateDpad(m: Mapping) {
        var vx = (if (m.right in held) 1f else 0f) - (if (m.left in held) 1f else 0f)
        var vy = (if (m.down in held) 1f else 0f) - (if (m.up in held) 1f else 0f)
        if (vx != 0f && vy != 0f) { vx *= 0.7071f; vy *= 0.7071f }
        applyVec(m, vx, vy)
    }

    private fun updateSticks() {
        if (!enabled) return
        for (m in maps) {
            if (m.type != MType.STICK) continue
            var vx = norm(m.ax)
            var vy = norm(m.ay)
            val mag = hypot(vx, vy)
            if (mag < 0.2f) { vx = 0f; vy = 0f }
            else if (mag > 1f) { vx /= mag; vy /= mag }
            applyVec(m, vx, vy)
        }
    }

    private fun applyVec(m: Mapping, vx: Float, vy: Float) {
        val last = lastVec[m]
        if (last != null && abs(last.first - vx) < 0.01f && abs(last.second - vy) < 0.01f) return
        lastVec[m] = vx to vy

        val cx = px(m.x); val cy = py(m.y); val r = rad(m)
        val id = stickPtr[m]
        if (vx == 0f && vy == 0f) {
            if (id != null) { inj.up(id); stickPtr.remove(m) }
            return
        }
        val tx = cx + vx * r; val ty = cy + vy * r
        if (id == null) {
            val nid = inj.down(cx, cy)
            if (nid < 0) return
            stickPtr[m] = nid
            inj.move(nid, tx, ty)
        } else {
            inj.move(id, tx, ty)
        }
    }
}
