package uz.elevate.padmap

import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Ekranga bosish yuboruvchi (Accessibility gesture orqali). */
interface Injector {
    fun down(x: Float, y: Float): Int
    fun move(id: Int, x: Float, y: Float)
    fun up(id: Int)
    fun releaseAll()
}

/**
 * Gamepad hodisalarini ekran bosishlariga aylantiradi. Faqat bitta (exec) oqimda chaqiriladi.
 * Kirish: tugmalar (Linux kodlari, Codes.fromKeyCode orqali) va o'qlar (-1..1, triggerlar 0..1).
 * O'q kodlari: 0=X 1=Y 2=Z 3=RX 4=RY 5=RZ 9=GAS 10=BRAKE 0x10=HAT_X 0x11=HAT_Y
 */
class Engine(
    private val inj: Injector,
    private val exec: ScheduledExecutorService,
) {
    var enabled = true
    var captureMode = 0
    var captureCb: ((Int) -> Unit)? = null

    private var maps: List<Mapping> = emptyList()
    private var W = 2400f
    private var H = 1080f

    private val held = HashSet<Int>()
    private val active = HashMap<Int, Act>()
    private val swipes = HashSet<SwipeAct>()
    private val axis = FloatArray(64)
    private val absBtn = BooleanArray(64)
    private val stickPtr = HashMap<Mapping, Int>()
    private val lastVec = HashMap<Mapping, Pair<Float, Float>>()

    fun setProfile(list: List<Mapping>, w: Int, h: Int) {
        releaseAll()
        maps = list
        W = w.toFloat(); H = h.toFloat()
    }

    fun releaseAll() {
        swipes.forEach { it.cancel() }
        swipes.clear()
        active.clear()
        stickPtr.clear()
        lastVec.clear()
        inj.releaseAll()
    }

    private fun px(f: Float) = f * W
    private fun py(f: Float) = f * H
    private fun rad(m: Mapping) = m.r * min(W, H)

    // ---------- kirish ----------

    fun onKey(code: Int, down: Boolean) = keyEvent(code, down)

    fun onAxis(code: Int, v: Float) {
        if (code < 0 || code >= 64) return
        axis[code] = v
        when (code) {
            0x10 -> hat(Codes.HAT_LEFT, Codes.HAT_RIGHT, v)
            0x11 -> hat(Codes.HAT_UP, Codes.HAT_DOWN, v)
            else -> {
                if (captureMode == 2) captureStick(code)
                absButton(code)
            }
        }
    }

    /** Bir paket o'qlardan keyin chaqiriladi */
    fun sync() = updateSticks()

    private fun hat(neg: Int, pos: Int, v: Float) {
        when {
            v < -0.5f -> { keyEvent(pos, false); keyEvent(neg, true) }
            v > 0.5f -> { keyEvent(neg, false); keyEvent(pos, true) }
            else -> { keyEvent(neg, false); keyEvent(pos, false) }
        }
    }

    /** Trigger kabi o'qlarni tugma sifatida ishlatish */
    private fun absButton(code: Int) {
        if (maps.any { it.type == MType.STICK && (it.ax == code || it.ay == code) }) return
        val m = abs(axis[code])
        if (!absBtn[code] && m > 0.6f) { absBtn[code] = true; keyEvent(Codes.ABS_BTN + code, true) }
        else if (absBtn[code] && m < 0.3f) { absBtn[code] = false; keyEvent(Codes.ABS_BTN + code, false) }
    }

    private fun captureStick(code: Int) {
        if (abs(axis[code]) < 0.6f) return
        val pair = when (code) {
            0, 1 -> 0 to 1
            3, 4 -> 3 to 4
            2, 5 -> 2 to 5
            else -> return
        }
        finishCapture(pair.first or (pair.second shl 16))
    }

    private fun finishCapture(code: Int) {
        val cb = captureCb
        captureMode = 0
        captureCb = null
        try { cb?.invoke(code) } catch (_: Exception) {}
    }

    private fun keyEvent(code: Int, down: Boolean) {
        if (down) { if (!held.add(code)) return } else { if (!held.remove(code)) return }

        if (captureMode == 1 && down) { finishCapture(code); return }
        if (!enabled) return

        for (m in maps) {
            if (m.type == MType.DPAD && (code == m.up || code == m.down || code == m.left || code == m.right)) {
                updateDpad(m)
            }
        }

        if (down) {
            val isAct = { m: Mapping -> m.type == MType.TAP || m.type == MType.SWIPE }
            // Avval kombinatsiya (mod bosib turilgan bo'lsa), keyin oddiy bog'lanish
            val m = maps.firstOrNull { isAct(it) && it.key == code && it.mod != 0 && it.mod in held }
                ?: maps.firstOrNull { isAct(it) && it.key == code && it.mod == 0 }
                ?: return
            active.remove(code)?.end()
            active[code] = if (m.type == MType.TAP) TapAct(m) else SwipeAct(m)
        } else {
            active.remove(code)?.end()
        }
    }

    // ---------- harakatlar ----------

    private abstract inner class Act { abstract fun end() }

    private inner class TapAct(m: Mapping) : Act() {
        val id = inj.down(px(m.x), py(m.y))
        override fun end() { if (id >= 0) inj.up(id) }
    }

    /** Bosib, ma'lum vaqt ichida surish (FC Mobile: shoot'ni bosib tortish) */
    private inner class SwipeAct(private val m: Mapping) : Act() {
        private val id = inj.down(px(m.x), py(m.y))
        private val steps = max(1, m.ms / 20)
        private var step = 0
        private var released = false
        private var done = false
        private var fut: ScheduledFuture<*>? = null

        init {
            if (id >= 0) {
                swipes.add(this)
                fut = exec.scheduleAtFixedRate({ tick() }, 20, 20, TimeUnit.MILLISECONDS)
            }
        }

        private fun tick() {
            step++
            val t = (step.toFloat() / steps).coerceAtMost(1f)
            inj.move(id, px(m.x + (m.x2 - m.x) * t), py(m.y + (m.y2 - m.y) * t))
            if (step >= steps) {
                fut?.cancel(false)
                done = true
                if (released) { inj.up(id); swipes.remove(this) }
            }
        }

        override fun end() {
            released = true
            if (id < 0) return
            if (done) { inj.up(id); swipes.remove(this) }
        }

        fun cancel() { fut?.cancel(false) }
    }

    private fun updateDpad(m: Mapping) {
        var vx = (if (m.right in held) 1f else 0f) - (if (m.left in held) 1f else 0f)
        var vy = (if (m.down in held) 1f else 0f) - (if (m.up in held) 1f else 0f)
        if (vx != 0f && vy != 0f) { vx *= 0.7071f; vy *= 0.7071f }
        applyVec(m, vx, vy)
    }

    private fun updateSticks() {
        if (!enabled) return
        for (m in maps) {
            if (m.type != MType.STICK) continue
            var vx = axis[m.ax.coerceIn(0, 63)]
            var vy = axis[m.ay.coerceIn(0, 63)]
            val mag = hypot(vx, vy)
            if (mag < 0.2f) { vx = 0f; vy = 0f }
            else if (mag > 1f) { vx /= mag; vy /= mag }
            applyVec(m, vx, vy)
        }
    }

    private fun applyVec(m: Mapping, vx: Float, vy: Float) {
        val last = lastVec[m]
        if (last != null && abs(last.first - vx) < 0.03f && abs(last.second - vy) < 0.03f) return
        lastVec[m] = vx to vy

        val cx = px(m.x); val cy = py(m.y); val r = rad(m)
        val id = stickPtr[m]
        if (vx == 0f && vy == 0f) {
            if (id != null) { inj.up(id); stickPtr.remove(m) }
            return
        }
        val tx = cx + vx * r; val ty = cy + vy * r
        if (id == null) {
            val nid = inj.down(cx, cy)
            if (nid < 0) return
            stickPtr[m] = nid
            inj.move(nid, tx, ty)
        } else {
            inj.move(id, tx, ty)
        }
    }
}
