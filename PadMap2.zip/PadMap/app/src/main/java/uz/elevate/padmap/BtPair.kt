package uz.elevate.padmap

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast

/** Ilova ichida Bluetooth gamepadni qidirish va juftlash. */
@SuppressLint("MissingPermission")
class BtPair(private val act: Activity) {

    private val adapter: BluetoothAdapter? =
        act.getSystemService(BluetoothManager::class.java)?.adapter
    private val devices = ArrayList<BluetoothDevice>()
    private val labels = ArrayList<String>()
    private val listAdapter = ArrayAdapter(act, android.R.layout.simple_list_item_1, labels)
    private var registered = false
    private var dialog: AlertDialog? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            @Suppress("DEPRECATION")
            val dev = i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> dev?.let { add(it) }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
                    if (dev != null && st == BluetoothDevice.BOND_BONDED) {
                        toast("✅ ${dev.name ?: dev.address} ulandi. Endi o'yinni oching.")
                    }
                    rebuild()
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> dialog?.setTitle("Qidiruv tugadi")
            }
        }
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf("android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT")
        else arrayOf("android.permission.ACCESS_FINE_LOCATION")

    fun show() {
        val a = adapter ?: run { toast("Bu telefonda Bluetooth yo'q"); return }
        val need = perms().filter { act.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) {
            act.requestPermissions(need.toTypedArray(), 5)
            toast("Ruxsat bering va tugmani yana bosing")
            return
        }
        if (!a.isEnabled) {
            act.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        if (!registered) {
            act.registerReceiver(receiver, IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            })
            registered = true
        }
        devices.clear()
        a.bondedDevices?.forEach { add(it) }
        rebuild()
        if (a.isDiscovering) a.cancelDiscovery()
        a.startDiscovery()

        dialog = AlertDialog.Builder(act)
            .setTitle("Qidirilmoqda… Gamepadni ulash rejimiga qo'ying")
            .setAdapter(listAdapter) { _, which -> pick(devices[which]) }
            .setNeutralButton("Bluetooth sozlamalari") { _, _ ->
                act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            }
            .setNegativeButton("Yopish", null)
            .setOnDismissListener { a.cancelDiscovery() }
            .show()
    }

    private fun isPad(d: BluetoothDevice): Boolean =
        d.bluetoothClass?.majorDeviceClass == BluetoothClass.Device.Major.PERIPHERAL

    private fun add(d: BluetoothDevice) {
        if (devices.any { it.address == d.address }) return
        if (d.name.isNullOrBlank() && !isPad(d)) return
        devices.add(d)
        // Gamepadga o'xshaganlar tepada
        devices.sortByDescending { isPad(it) }
        rebuild()
    }

    private fun rebuild() {
        labels.clear()
        devices.forEach { d ->
            val icon = if (isPad(d)) "🎮 " else "• "
            val st = when (d.bondState) {
                BluetoothDevice.BOND_BONDED -> "  ✓ juftlangan"
                BluetoothDevice.BOND_BONDING -> "  … ulanmoqda"
                else -> ""
            }
            labels.add(icon + (d.name ?: d.address) + st)
        }
        listAdapter.notifyDataSetChanged()
    }

    private fun pick(d: BluetoothDevice) {
        adapter?.cancelDiscovery()
        if (d.bondState == BluetoothDevice.BOND_BONDED) {
            toast("Allaqachon juftlangan. Gamepadni yoqing — o'zi ulanadi.")
        } else {
            toast("Ulanmoqda: ${d.name ?: d.address}")
            d.createBond()
        }
    }

    fun release() {
        if (registered) try { act.unregisterReceiver(receiver) } catch (_: Exception) {}
        registered = false
    }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_LONG).show()
}
