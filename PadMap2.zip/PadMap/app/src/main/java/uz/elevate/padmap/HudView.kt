package uz.elevate.padmap

import android.annotation.SuppressLint
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** O'yin paytida tugmalarni shaffof ko'rsatib turadi (bosishlarga xalaqit bermaydi). */
@SuppressLint("ViewConstructor")
class HudView(private val svc: OverlayService) : View(svc) {

    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2 * d; strokeCap = Paint.Cap.ROUND
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(6 * d, 6 * d), 0f)
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 12 * d; textAlign = Paint.Align.CENTER; isFakeBoldText = true
        setShadowLayer(3 * d, 0f, 0f, Color.BLACK)
    }

    private fun disc(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.color = (color and 0x00FFFFFF) or 0x33000000
        c.drawCircle(x, y, r, fill)
        ring.color = (color and 0x00FFFFFF) or 0xCC000000.toInt()
        c.drawCircle(x, y, r, ring)
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float) = c.drawText(s, x, y + txt.textSize / 3, txt)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val md = min(w, h)
        val maps = svc.maps
        for (m in maps) {
            if (m.group != 0) continue
            val x = m.x * w; val y = m.y * h; val r = m.r * md
            when (m.type) {
                MType.TAP -> { disc(c, x, y, r, 0xFF2979FF.toInt()); label(c, Codes.label(m), x, y) }
                MType.STICK -> { disc(c, x, y, r, 0xFF00C853.toInt()); disc(c, x, y, r * 0.3f, 0xFF00C853.toInt()) }
                MType.DPAD -> { disc(c, x, y, r, 0xFFAA00FF.toInt()); label(c, "✚", x, y) }
                else -> {}
            }
        }
        maps.filter { it.group != 0 }.groupBy { it.group }.values.forEach { g ->
            val f = g[0]
            val x = f.x * w; val y = f.y * h; val r = f.r * md
            val orange = 0xFFFF6D00.toInt()
            for (m in g) if (m.type == MType.SWIPE) {
                line.color = (orange and 0x00FFFFFF) or 0xAA000000.toInt()
                c.drawLine(x, y, m.x2 * w, m.y2 * h, line)
                disc(c, m.x2 * w, m.y2 * h, 9 * d, orange)
                c.drawText(Codes.label(m), m.x2 * w, m.y2 * h + 22 * d, txt)
            }
            disc(c, x, y, r, orange)
            val body = g.firstOrNull { it.type == MType.TAP }
            label(c, body?.let { Codes.label(it) } ?: f.name.ifEmpty { "Shoot" }, x, y)
        }
    }
}
